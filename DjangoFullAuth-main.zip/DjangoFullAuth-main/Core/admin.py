from django.contrib import admin
from .models import PasswordReset

admin.site.register(PasswordReset)